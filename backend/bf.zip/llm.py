from langchain_groq import ChatGroq
import os

llm = ChatGroq(
    model="llama-3.3-70b-versatile",
    api_key="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",
    temperature=0
)